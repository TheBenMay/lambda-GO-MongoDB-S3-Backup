**To delete a trail**

The following ``delete-trail`` command deletes a trail named ``Trail1``::

  aws cloudtrail delete-trail --name Trail1
  